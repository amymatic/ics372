import java.io.*;

public class Main {
    /*
    Instruction:

    -Initially, run the program which calls method ‘writeToFile()’
	    ->this will store the object into binary files

    -In second run, comment out the ‘writeToFile()’ and run only ‘readFile()’
        ->reads from binary file which contains object info

     */

    public static void main(String[] args) throws IOException, ClassNotFoundException {
        Person [] list = new Person[3];//collection of objects
        Person mike = new Person("Mike", 33);
        Person tom = new Person("Tom", 54);
        Person kate = new Person("Kate ", 25);
        list[0] = mike;
        list[1] = tom;
        list[2] = kate;

        //writeToFile(list);
        readFile();
    }

    //Serialization
    public static void writeToFile(Person [] list) throws IOException {
        ObjectOutputStream objectOutputStream = new ObjectOutputStream(new FileOutputStream("Person.bin"));
        for(int i = 0; i < list.length; i++) {
            objectOutputStream.writeObject(list[i]);
        }
    }

    //Deserialization
    public static void readFile() throws IOException, ClassNotFoundException{
        ObjectInputStream objectInputStream= new ObjectInputStream(new FileInputStream("Person.bin"));
        Person list[] = new Person[3];

        for (int i = 0; i < list.length; i++) {

            list[i] = (Person) objectInputStream.readObject();
            System.out.println(list[i]);

        }

    }
}
